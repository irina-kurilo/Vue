<template>
    <el-button type="success" @click="getData">Покемон</el-button>
    
    <div>
    <el-row>
     
    <el-col>
       <div v-for="item in pokemon" :key="item"> 
      <el-card :body-style="{ padding: '0px' }">
        <img
          src="https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png"
          class="image"
        />
        <div style="padding: 14px">
          <span>  {{ item.name}}</span><br>
          <span v-for="items in abilitys" :key="items">  
            {{ items.name}}
        </span>
        </div>
      </el-card>
    </div>
    </el-col>
  </el-row>
</div>

     <div>


<el-pagination
      v-model:current-page="currentPage"
      v-model:page-size="pageSize"
      :page-sizes="[20, 50, 100, 200]"
      layout="sizes, prev, pager, next"
      :total="totalCount"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
 
    />
</div>
</template>
<script>
export default{
    data() {return{
      
        currentPage:1,
        pageSize:20,
    totalCount:0,
    pokemon: []}
},
props:[

],
name:``,
components:[],

methods:{
getData(){

    console.log(`https://pokeapi.co/api/v2/pokemon?offset=${(this.currentPage-1)*this.pageSize}&limit=${this.pageSize}`);
    this.axios.get(`https://pokeapi.co/api/v2/pokemon?offset=${(this.currentPage-1)*this.pageSize}&limit=${this.pageSize}`).then((response) => {
       if(response){
        this.totalCount=response.data.count;
        this.pokemon = response.data.results;

        }
        // 
        console.log(response);
        //this.requestData=response;
    }).catch((error) => {
        console.warn(error);
    })

},

handleSizeChange(){
        this.currentPage = this.currentPage-1;
        this.getData()
    },
    handleCurrentChange(){
        this.getData()
    },
    mounted(){
         this.getData()
    }
}}

</script>